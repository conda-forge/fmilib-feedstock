The minizip code has been obtained from http://www.winimage.com/zLibDll/minizip.html on 27.01.2012. 
It was modified to fit specific project requirements.

List of changes made to minizip without any guaranty that this list is updated or correct.
 - main functions replaced with regular function names.
 - replaced exit(..) calls with function returns.
 - suppressed messages written to stdout(printf) with an empty function.
 - minor platform dependent bug fixes.
 - maybe other changes has been made.