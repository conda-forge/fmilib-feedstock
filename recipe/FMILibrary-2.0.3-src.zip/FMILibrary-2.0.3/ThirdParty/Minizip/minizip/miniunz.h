#ifndef MINIUNZ_H
#define MINIUNZ_H
#ifdef __cplusplus 
extern "C" {
#endif

int miniunz(int argc , char *argv[]); /* Renamed the main function */
#ifdef __cplusplus 
}
#endif
#endif /* End of header file MINIUNZ_H */
