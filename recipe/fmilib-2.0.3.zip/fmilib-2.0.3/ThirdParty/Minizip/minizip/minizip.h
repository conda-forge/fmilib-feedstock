#ifndef MINIZIP_H
#define MINIZIP_H
#ifdef __cplusplus 
extern "C" {
#endif

int minizip(int argc , char *argv[]); /* Renamed the main function */

#ifdef __cplusplus 
}
#endif
#endif /* End of header file MINIZIP_H */
